
# Prodigy Online Dashboard
[Live website](https://prodigy-dashboard.hostedposted.com/)

Prodigy Online Dashboard is an online application to hack [Prodigy](https://prodigygame.com).

## Installation

Download this branch, and simply open index.html and you're ready to go!
## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate (and recommended).

## License
[Creative Commons](https://github.com/hostedposted/Prodigy/blob/dashboard/LICENSE)
